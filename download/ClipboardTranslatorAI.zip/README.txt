Clipboard Translator AI
======================

Desenvolvido por Paulo A. Giavoni

Instruções:
1. Execute o arquivo ClipboardTranslatorAI
2. Configure as opções de idioma e API
3. Clique em 'Iniciar Monitoramento' para começar a traduzir

Obrigado por usar o Clipboard Translator AI!