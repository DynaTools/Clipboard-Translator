Clipboard Translator AI - Código Fonte
===================================

Desenvolvido por Paulo A. Giavoni

Instruções para executar o código fonte:

1. Extraia o conteúdo do arquivo ZIP
2. Instale as dependências usando:
   pip install -r requirements.txt

3. Execute o programa usando:
   python main-py.py

Obrigado por usar o Clipboard Translator AI!