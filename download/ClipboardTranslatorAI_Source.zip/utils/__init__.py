
"""
Utility modules for the translator application
"""
